Crafteryada by Uziush



>>What is Crafteryada?<<

Crafteryada is a 32x Resource Pack. It has an organic look themed around nature with a medieval twist, suitable for building gardens and picturesque ruins. This pack started as a 32x remake of Charlotte Pack, but after making a few textures I decided to create something entirely new and thus Crafteryada was born. Crafteryada is a vanilla pack, that means that you don�t have to install any mods to enjoy its full potential. MC Patcher and OptiFine are not required, because the pack will rely on the vanilla feature of alternate blocks. There are only a few right now, but more will come.




>>The name �Crafteryada�<<

Crafteryada can be roughly translated to English as �Crafting festival�. The suffix �~iada� (read as �~yada�) is often used in the Polish language in the names of cultural and sport events such as the Olympic Games (�olimpiada�) or feast (�biesiada�). The �i� was changed to �y� to give it an old Slavic feel similar to the Polish language in medieval times. This is an anachronistic version of this suffix and it�s an integral part of the pack�s name so only the first letter is capitalized.




>>Legal: YouTube, maps and remixes and all you need to know<<

You are free to use this pack in your YouTube videos. I only ask you to provide a link to my download and to get the name right.

You are free to use it for screenshots and your maps, just don�t provide the pack as a bundle in your download. Provide a link to the official download instead.

You cannot use Crafteryada as a server pack. If you want your players to use it provide a link to the download at your server�s site or in any other form on the server itself (signs on the spawn, server messages etc.)

You are free to modify the pack for your own use, but you cannot distribute the modified package or claim it as your own.

I do not allow any remixes and rehosting on other sites - you can only provide a link to my download page. Any adf.ly links are forbidden (I do not use it and it indicates a fake link).

The official link to the download (the link auto updates to the latest version of Crafteryada and is never out of date):

http://www.curse.com/texture-packs/minecraft/crafteryada/download




>>Final notes<<

As this is a Work in Progress version of the pack I reserve the right to make some big changes in existing textures or even replace some of them in future updates.




>>Donation<<

I don't want to use adf.ly or anything else that may affect the download of my resource packs. All my resource packs are created in my free time and all gathered funds will be used on software and hardware useful in their development. If you want to aid me in the development of Crafteryada and future resource packs please consider donation via PayPal: uziush@gmail.com




Please send all comments to: uziush@gmail.com


Best regards,
Uziush




DOWNLOAD LINK:

http://www.curse.com/texture-packs/minecraft/crafteryada/download
